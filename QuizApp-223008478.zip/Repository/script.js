const quizContainer = document.getElementById('quiz-container');
const questionContainer = document.getElementById('question-container');
const questionElement = document.getElementById('question');
const answerButtonsElement = document.getElementById('answer-buttons');
const startButton = document.getElementById('start-button');
const nextButton = document.getElementById('next-button');

let shuffledQuestions, currentQuestionIndex;

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', () => {
  currentQuestionIndex++;
  setNextQuestion();
});

function startQuiz() {
  startButton.classList.add('hide');
  shuffledQuestions = questions.sort(() => Math.random() - 0.5);
  currentQuestionIndex = 0;
  questionContainer.classList.remove('hide');
  setNextQuestion();
}

function setNextQuestion() {
    resetState();
    showQuestion(shuffledQuestions[currentQuestionIndex]);
  }
  
  function showQuestion(question) {
    questionElement.innerText = question.question;
    question.answers.forEach(answer => {
      const button = document.createElement('button');
      button.innerText = answer.text;
      button.classList.add('answer-button');
      if (answer.correct) {
        button.dataset.correct = answer.correct;
      }
      button.addEventListener('click', selectAnswer);
      answerButtonsElement.appendChild(button);
    });
  }
  
  function resetState() {
    clearStatusClass(document.body);
    nextButton.classList.add('hide');
    while (answerButtonsElement.firstChild) {
      answerButtonsElement.removeChild(answerButtonsElement.firstChild);
    }
  }
  
  function selectAnswer(e) {
    const selectedButton = e.target;
    const correct = selectedButton.dataset.correct;
    setStatusClass(document.body, correct);
    Array.from(answerButtonsElement.children).forEach(button => {
      setStatusClass(button, button.dataset.correct);
    });
    if (shuffledQuestions.length > currentQuestionIndex + 1) {
      nextButton.classList.remove('hide');
    } else {
      startButton.innerText = 'Restart';
      startButton.classList.remove('hide');
    }
  }
  
  function setStatusClass(element, correct) {
    clearStatusClass(element);
    if (correct) {
      element.classList.add('correct');
    } else {
      element.classList.add('wrong');
    }
  }
  
  function clearStatusClass(element) {
    element.classList.remove('correct');
    element.classList.remove('wrong');
  }
  
  const questions = [  {    question: 'What is 2 + 2?',    answers: [      { text: '4', correct: true },      { text: '22', correct: false }    ]
    },
    {
      question: 'Who is the best football player in the world?',
      answers: [
        { text: 'Lionel Messi', correct: true },
        { text: 'Cristiano Ronaldo', correct: true },
        { text: 'Neymar Jr.', correct: true },
        { text: 'Kylian Mbappé', correct: true }
      ]
    },
	{
      question: 'Which flies a green, white, and orange (in that order) tricolor flag?',
      answers: [
        { text: 'Ireland', correct: false },
        { text: 'Ivory Coast', correct: false },
        { text: 'Italy', correct: true },
        { text: 'Ghana', correct: false }
      ]
    }, 
	{
      question: 'What company makes the Xperia model of smartphone?',
      answers: [
        { text: 'Samsung', correct: false },
        { text: 'Apple', correct: false },
        { text: 'Sony', correct: true },
        { text: 'Nokia', correct: false }
      ]
    },
	{
      question: 'Which of the following is NOT a fruit?',
      answers: [
        { text: 'Mango', correct: false },
        { text: 'Apple', correct: false },
        { text: 'Rhubarb', correct: true },
        { text: 'Tomato', correct: false }
      ]
    },
	{
      question: 'Where was the first example of paper money used?',
      answers: [
        { text: 'China', correct: true },
        { text: 'Turkey', correct: false },
        { text: 'Greece', correct: false },
        { text: 'Japan', correct: false }
      ]
    },
	{
      question: 'Who is generally considered the inventor of the motor car?',
      answers: [
        { text: 'Karl Benz', correct: true },
        { text: 'Henry Ford', correct: false },
        { text: 'Henry M. Leland', correct: false },
        { text: 'Karim Benzema', correct: false }
      ]
    },
	{
      question: 'What number was the Apollo mission that successfully put a man on the moon for the first time in human history?',
      answers: [
        { text: 'Apollo 12', correct: false },
        { text: 'Apollo 20', correct: false },
        { text: 'Apollo 11', correct: true },
        { text: 'Apollo 19', correct: false }
      ]
    },
	{
      question: ' Which of the following languages has the longest alphabet?',
      answers: [
        { text: 'English', correct: false },
        { text: 'Russian', correct: true },
        { text: 'Chinese', correct: false },
        { text: 'Korean', correct: false }
      ]
    },
    {
      question: 'What is the capital city of Australia?',
      answers: [
        { text: 'Sydney', correct: false },
        { text: 'Melbourne', correct: false },
        { text: 'Brisbane', correct: false },
        { text: 'Canberra', correct: true }
      ]
    }
  ];
	var score = 0; // initialize score to 0

// add 1 to score when a correct answer is chosen
	function updateScore() {
    score += 1;
    document.getElementById("score").innerHTML = score;
}

// reset score to 0 when the quiz is restarted
	function resetScore() {
    score = 0;
    document.getElementById("score").innerHTML = score;
}

 
  function showFeedback() {
  const questionContainerElement = document.getElementById('question-container');
  const controlsElement = document.getElementById('controls');
  const feedbackContainerElement = document.getElementById('feedback-container');
  const score = Math.round((correctAnswers / questions.length) * 100);

  questionContainerElement.classList.add('hide');
  controlsElement.classList.add('hide');
  feedbackContainerElement.classList.remove('hide');

  feedbackContainerElement.innerHTML = `
    <h2>Your score: ${score}%</h2>
    <p>You got ${correctAnswers} out of ${questions.length} questions correct.</p>
    <button id="restart-button">Restart Quiz</button>
  `;
  
  const restartButton = document.getElementById('restart-button');
  restartButton.addEventListener('click', restartQuiz);
}
